# Intrucciones del ejercicio
El cliente nos acaba de pasar el proyecto que otro desarrollador le cobró un dineral por hacerlo y resulta que no funciona ....

El cliente quiere que le arreglemos el proyecto.

Los requerimientos que describe el cliente son:
- Es un boton al centro de la pantalla que dice: "Touch me"
- Y una cajita texto debajo del botón, al presionar el botón mandará un mensaje
- Lo quiere para un iPhone 8 en portrait

Entregar:
1. El proyecto funcionando (no se permite re hacer el proyecto, se tiene que resolver en el mismo proyecto)
2. Comentar en código donde se hicieron modificaciones
3. Hacer un archivo observaciones.md, donde se haga un reporte técnico de lo que pasaba y estaba mal, poner los nombres de error y razones que muestra la ventana de depuración de código, o si se tuvo que quitar algo y conclusiones de la actividad.
4. Subir a su repositorio en github
