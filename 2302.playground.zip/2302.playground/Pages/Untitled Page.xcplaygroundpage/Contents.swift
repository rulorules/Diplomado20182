//: Playground - noun: a place where people can play

import UIKit

func funcion(palabra: String){
    print("hola funcion \(palabra)")
}

var variable = funcion
variable("hola chavitos")
